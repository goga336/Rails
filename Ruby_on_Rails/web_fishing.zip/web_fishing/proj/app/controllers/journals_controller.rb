class JournalsController < ApplicationController
  def new
    @jour = Journale.new
    set_greeting
    user_id = cookies[:user_id] 
    @data_den = Journale.where(id_j: user_id).pluck(:den)
    @data_count_ryb = Journale.where(id_j: user_id).pluck(:count_ryb)
  end

  def create
    user_id = cookies[:user_id]
    @jour = Journale.new(jour_params.merge(id_j: user_id.to_i))
    # @jour = Journale.new(jour_params)
    if @jour.save

    else
       set_greeting
      render :new
    end
  end

  private

  def set_greeting
    user_id = cookies[:user_id]
    @greeting = user_id.present? ? "Привет, #{current_user.email}" : "Пользователь не аутентифицирован"
    @gr = user_id.present? ? "Привет, #{current_user.password}" : ""
  end

  def jour_params
    params.require(:journale).permit(:comment, :count_ryb, :den)
  end
end
