# ерунда








class MainController < ApplicationController
  def new
    @jour = Journale.new
    set_greeting
  end

  def create
    @jour = Journale.new(jour_params)
    if @jour.save
      render :new
    else
      set_greeting
      render :new
    end
  end

  private

  def set_greeting
    user_id = cookies[:user_id]
    @greeting = user_id.present? ? "Привет, #{current_user.email}" : "Пользователь не аутентифицирован"
    @gr = user_id.present? ? "Привет, #{current_user.password}" : ""
  end

  def jour_params
    params.require(:journale).permit(:comment, :count_ryb, :den)
  end
end
