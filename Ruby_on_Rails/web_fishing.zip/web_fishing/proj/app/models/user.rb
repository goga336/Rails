class User < ApplicationRecord

end
