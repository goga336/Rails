class Journale < ApplicationRecord
end
