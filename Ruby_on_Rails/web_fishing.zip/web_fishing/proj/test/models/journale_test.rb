require "test_helper"

class JournaleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
