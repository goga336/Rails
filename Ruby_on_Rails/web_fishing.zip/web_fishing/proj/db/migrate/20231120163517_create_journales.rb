class CreateJournales < ActiveRecord::Migration[7.1]
  def change
    create_table :journales do |t|
      t.integer :id_j
      t.string :comment
      t.integer :count_ryb
      t.date :den

      t.timestamps
    end
  end
end
