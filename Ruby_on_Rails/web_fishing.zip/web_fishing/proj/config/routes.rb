Rails.application.routes.draw do
  get 'sessions/new'
   #resources :posts
  get '/register', to: 'users#new'
   resources :users
  # get '/main_page', to: 'main#page', as: 'main_page'
  get'/main_page', to: 'journals#new'
  # routes.rb
  resources :journals

  #resources :main
  get '/sign_in', to: 'sessions#new'
  get '/sign_out', to: 'sessions#destroy'
   resources :sessions
end
